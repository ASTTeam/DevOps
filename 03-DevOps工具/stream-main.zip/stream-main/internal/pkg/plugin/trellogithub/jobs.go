package trellogithub

// Jobs is the struct for github actions custom config.
type Jobs struct {
}
