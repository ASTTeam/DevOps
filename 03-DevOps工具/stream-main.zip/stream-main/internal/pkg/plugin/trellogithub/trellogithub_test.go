package trellogithub

import (
	. "github.com/onsi/ginkgo/v2"
)

var _ = Describe("Trellogithub", func() {
	// TODO(daniel-hutao): implement the unit tests
})
