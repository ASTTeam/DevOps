package devlake

type Param struct{}
