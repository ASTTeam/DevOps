package zip

import (
	. "github.com/onsi/ginkgo/v2"
	//. "github.com/onsi/gomega"
)

var _ = Describe("Zip", func() {
	Context("Targz", func() {
		It("Should untargz", func() {
			// TODO(daniel-hutao): uncomment the code below after zip.Targz() function is implemented.
			//var testFile = "dtm-scaffolding-golang-v0.0.1.tar.gz"
			//err := UnTargz(testFile)
			//Expect(err).NotTo(HaveOccurred())
		})
	})
})
