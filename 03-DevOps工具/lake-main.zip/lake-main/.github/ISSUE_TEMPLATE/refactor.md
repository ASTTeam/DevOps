---
name: Refactor
about: Improve operation without altering functionality
title: ''
labels: type/refactor
assignees: ''

---

## What and why to refactor
What are you trying to refactor? Why should it be refactored now?

## Describe the solution you'd like
How to refactor?

## Related issues
Please link any other

## Additional context
Add any other context or screenshots about the feature request here.
