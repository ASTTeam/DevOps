const NullPipelineTask = {
  ID: null,
  CreatedAt: null,
  UpdatedAt: null,
  plugin: null,
  options: {
  },
  status: 'TASK_CREATED',
  message: '',
  progress: 0,
  pipelineId: null,
  pipelineRow: 1,
  pipelineCol: 1,
  beganAt: null,
  finishedAt: null,
  spentSeconds: 0

}

export {
  NullPipelineTask
}
