const AVAILABLE_PLUGINS = ['gitlab', 'jira', 'jenkins', 'github']

module.exports = AVAILABLE_PLUGINS
