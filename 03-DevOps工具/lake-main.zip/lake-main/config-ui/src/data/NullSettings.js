const NullSettings = {
  JIRA_BASIC_AUTH_ENCODED: null,
  JIRA_ISSUE_EPIC_KEY_FIELD: null,
  JIRA_ISSUE_TYPE_MAPPING: null,
  JIRA_ISSUE_STORYPOINT_FIELD: null,
  JIRA_BOARD_GITLAB_PROJECTS: null,
}

export {
  NullSettings
}
