const gitlabConfig = [[{
  Plugin: 'gitlab',
  Options: {
    projectId: 278964
  }
}]]

export {
  gitlabConfig
}
