const gitextractorConfig = [
  [
    {
      Plugin: 'gitextractor',
      Options: {
        url: 'https://github.com/merico-dev/lake.git',
        repoId: 'github:GithubRepo:384111310'
      }
    }
  ]
]

export {
  gitextractorConfig
}
