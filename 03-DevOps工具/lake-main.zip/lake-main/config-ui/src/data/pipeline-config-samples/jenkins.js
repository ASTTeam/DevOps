const jenkinsConfig = [
  [
    {
      Plugin: 'jenkins',
      Options: {}
    }
  ]
]

export {
  jenkinsConfig
}
