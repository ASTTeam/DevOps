const githubConfig = [[{
  Plugin: 'github',
  Options: {
    repo: 'lake',
    owner: 'merico-dev'
  }
}]]

export {
  githubConfig
}
