const feishuConfig = [
  [
    {
      Plugin: 'feishu',
      Options: {}
    }
  ]
]

export {
  feishuConfig
}
