const NullPipelineRun = {
  ID: null,
  CreatedAt: null,
  UpdatedAt: null,
  name: null,
  tasks: [
    []
  ],
  totalTasks: 0,
  finishedTasks: 0,
  beganAt: null,
  finishedAt: null,
  status: null,
  message: '',
  spentSeconds: 0
}

export {
  NullPipelineRun
}
