const projectsData = [
  { id: 0, title: 'GL PRJ 3E4', value: 938191 },
  { id: 1, title: 'GL PRJ GG3', value: 23123 },
  { id: 2, title: 'GL PRJ 1XX', value: 653241 },
  { id: 3, title: 'GL PRJ 2X8', value: 1112 },
  { id: 4, title: 'GL PRJ 3FG', value: 51251251 },
  { id: 5, title: 'GL PRJ 789', value: 1211 },
  { id: 6, title: 'GL PRJ 22E', value: 34168 },
  { id: 7, title: 'GL PRJ 98Z', value: 9877673 },
  { id: 8, title: 'GL PRJ RR5', value: 657493 },
]

export {
  projectsData
}