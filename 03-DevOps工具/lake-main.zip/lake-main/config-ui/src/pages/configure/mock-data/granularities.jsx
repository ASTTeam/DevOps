const granularitiesData = [
  { id: 0, title: 'Story Points', value: 'customfield_6000' },
  { id: 1, title: 'Original Estimate', value: 'customfield_7000' },
]

export {
  granularitiesData
}