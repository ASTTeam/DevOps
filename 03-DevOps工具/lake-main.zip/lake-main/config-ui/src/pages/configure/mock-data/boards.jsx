const boardsData = [
  { id: 1, title: 'Open', value: 1 },
  { id: 2, title: 'Backlog', value: 2 },
  { id: 3, title: 'QA / Testing', value: 3 },
  { id: 4, title: 'Pre-release', value: 4 },
  { id: 5, title: 'Production', value: 5 },
  { id: 6, title: 'Closed', value: 6 }
]

export {
  boardsData
}
