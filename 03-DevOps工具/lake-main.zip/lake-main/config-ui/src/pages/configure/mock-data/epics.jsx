const epicsData = [
  { id: 0, title: 'Custom Field 1000', value: 'customfield_1000' },
  { id: 1, title: 'Custom Field 2000', value: 'customfield_2000' },
  { id: 2, title: 'Custom Field 3000', value: 'customfield_3000' },
  { id: 3, title: 'Custom Field 4000', value: 'customfield_4000' },
  { id: 4, title: 'Custom Field 5000', value: 'customfield_5000' },
]

export {
  epicsData
}
