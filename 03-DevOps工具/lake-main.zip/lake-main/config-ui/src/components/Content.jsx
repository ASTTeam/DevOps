import React, { Fragment } from 'react'
import '@/styles/common.scss'

const Content = ({ children }) => {
  return <>{children}</>
}

export default Content
