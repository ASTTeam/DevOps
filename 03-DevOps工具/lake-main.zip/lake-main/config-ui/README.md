## Getting Started

You can run the Front End by running:

```
npm i 
npm start
```

First, run the development server:

```bash
cd config-ui/src/server
npm i
npm start
```

The server will listen on http://localhost:5000