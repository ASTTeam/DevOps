# sync
create cron sync job for target data source.

```shell
# cd into lake-cli directory
cd cmd/lake-cli
# set api request body in req.json
vi req.json
# start sync job
docker-compose up sync
```
