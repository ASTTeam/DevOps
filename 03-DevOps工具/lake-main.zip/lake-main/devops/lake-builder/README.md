# lake-builder
golang builder image for lake, including go1.17.0 gcc10.3.1 g++10.3.1, libgit2 based on alpine linux 3.13.

https://hub.docker.com/r/mericodev/lake-builder

## release
```shell
export VERSION=0.0.2
docker build -t mericodev/lake-builder:$VERSION .
docker push mericodev/lake-builder:$VERSION
```
