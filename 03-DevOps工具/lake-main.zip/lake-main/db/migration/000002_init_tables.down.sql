BEGIN;

-- This line is required
USE lake_test;

SELECT now();

COMMIT;
